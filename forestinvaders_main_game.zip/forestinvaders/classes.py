import pygame as pg
import sys
import json
import os
class Bullet:
    def __init__(self,x,y, fr_spd,parent, alien_list, px_spd):
        self.pic = pg.transform.scale(pg.image.load("data\\sprites\\bullet.png"),(16 * parent.attribute_local_scale,16 * parent.attribute_local_scale))
        self.fr_spd = fr_spd
        self.delta_catchup = pg.time.get_ticks()
        self.has_hit = False
        self.alien_refs = alien_list
        self.damage = 1
        self.parent = parent
        self.rect = self.pic.get_rect(center=(x,y))
        self.rect.width = 4 * parent.attribute_local_scale
        self.rect.centerx += 7 * parent.attribute_local_scale
        self.rect.height = 6 * parent.attribute_local_scale
        self.rect.y += 30 * parent.attribute_local_scale
        self.px_spd = px_spd
        match parent.attribute_type:
            case 1:
                self.damage = 1
            case 4:
                self.damage = 3
            case _:
                self.damage = 1
    def update(self):
        now = pg.time.get_ticks()
        if now - self.delta_catchup > self.fr_spd:
            self.rect.y -= self.px_spd
            self.delta_catchup = now
        for alien in self.alien_refs:
            if alien.is_alive and self.has_hit == False:
                if self.rect.colliderect(alien.rect) and alien.rect.bottom > 0:
                    alien.health -= self.damage
                    if alien.health <= 0:
                        alien.is_alive = False
                    self.has_hit = True
        if self.has_hit == False:
            self.parent.winfo_scr.blit(self.pic, (self.rect.x - 8 * self.parent.attribute_local_scale, self.rect.y -8 * self.parent.attribute_local_scale))
            #pg.draw.rect(self.parent.winfo_scr, (255,255,255, 100), self.rect)
            
class Ship:
    def __init__(self, type, ship_base_scale,  W_width, W_height, W_Screen, Aliens):
        self.winfo_scr = W_Screen
        self.winfo_width = W_width
        self.winfo_height = W_height
        self.attribute_local_scale = ship_base_scale
        self.attribute_move_spd=14
        self.attribute_type = type
        self.attribute_image = pg.transform.scale(pg.image.load(f"data\\sprites\\extinguisher{type}.png"), (32 * ship_base_scale, 25*ship_base_scale))
        self.rect = self.attribute_image.get_rect(center=(W_width/2, W_height - 32 * ship_base_scale))
        self.ext_aliens = Aliens
        self.ext_delta_bullet_time = pg.time.get_ticks()
        self.reload_fr_interval = 5000
        match self.attribute_type:
            case 1:
                self.reload_fr_interval = 500
            case 2:
                self.reload_fr_interval = 350
    def draw(self):
        self.winfo_scr.blit(self.attribute_image, (self.rect.left, self.rect.centery))
    def input_calc(self, bullet_list):
        now = pg.time.get_ticks()
        keys = pg.key.get_pressed()
        if keys[pg.K_d] or keys[pg.K_RIGHT]:
            self.rect.x += self.attribute_move_spd
        if keys[pg.K_a] or keys[pg.K_LEFT]:
            self.rect.x -= self.attribute_move_spd
        self.rect.clamp_ip(pg.rect.Rect(0,0,self.winfo_width, self.winfo_height))
        if keys[pg.K_SPACE] and now - self.ext_delta_bullet_time > self.reload_fr_interval:
            sound = pg.mixer.Sound("data\\sounds\\bullet.mp3")
            sound.set_volume(.4)
            sound.play()
            match self.attribute_type:
                case 1:
                    bullet = Bullet(self.rect.centerx, self.rect.top, 50, self, self.ext_aliens, 5)
                case 2:
                    bullet = Bullet(self.rect.centerx + 12 * self.attribute_local_scale, self.rect.top,50,self, self.ext_aliens, 6)
                    bullet_list.append(bullet)
                    bullet = Bullet(self.rect.centerx - 12 * self.attribute_local_scale, self.rect.top,50,self, self.ext_aliens, 6)
            bullet_list.append(bullet)
            self.ext_delta_bullet_time  = now
class Alien:
    def __init__(self, type, alien_base_scale,  W_width, W_height, W_Screen):
        self.winfo_scr = W_Screen
        self.winfo_width = W_width
        self.winfo_height = W_height
        self.attribute_local_scale = alien_base_scale
        self.attribute_move_spd=14
        self.attribute_image = pg.transform.scale(pg.image.load(f"data\\sprites\\alien{type}.png"), (32 * alien_base_scale, 32*alien_base_scale))
        self.rect = self.attribute_image.get_rect()
        self.rect.centerx += 32000
        self.delta_catchup =pg.time.get_ticks()
        self.attribute_move_interval_fr = 500
        self.is_alive =True
        self.health = 1
        match type:
            case 1:
                self.health = 1
            case 2:
                self.health = 3
            case 3:
                self.health = 5
            case 4:
                self.health = 7
            case _:
                self.health =1
    def draw(self):
        self.winfo_scr.blit(self.attribute_image, self.rect.topleft)
        #pg.draw.ellipse(self.winfo_scr, 'blue', self.rect)
    def ai(self):
        now = pg.time.get_ticks()
        if now - self.delta_catchup > self.attribute_move_interval_fr:
            self.rect.y += self.attribute_move_spd
            self.delta_catchup = now

class Feature:
    def __init__(self, W_width, W_height, W_screen, Aliens):
        self.scr_width = W_width
        self.scr_height = W_height
        self.scr = W_screen
        self.ext_aliens = Aliens
    def load_level(self,level_data):
        ship = Ship(level_data['plr-type'], 3, self.scr_width, self.scr_height, self.scr, self.ext_aliens)
        perm_y_backup = 64 * (len(level_data['layout']) - 3)
        for row_index, row in enumerate(level_data['layout']):
            offset =0
            for col_index, cell in enumerate(row):
                if cell==0:
                    offset += self.scr_width / len(row)
                else:
                    alien = Alien(cell, 3,self.scr_width, self.scr_height, self.scr)
                    alien.rect.x = offset
                    alien.rect.y = row_index * 64 - perm_y_backup
                    offset += self.scr_width / len(row)
                    self.ext_aliens.append(alien)
        return ship
    def json_data(self, data):
        if os.path.exists(data):
            with open(data) as file:
                val = json.load(file)
                return val
        return None
    def find_level(self, list, target):
        return list[target]
    def implement_level(self,list, impl_list):
        max_idx = max(level['level-index'] for level in impl_list['levels'])
        list.extend([None] * (max_idx - len(list) + 1))
        for level in impl_list['levels']:
            index = level['level-index'] - 1
            list[index]  = level
class TextBox:
    def __init__(self,x,y,w,h,placeholder, scr_parent, font_size=32):
        self.rect = pg.rect.Rect(x, y, w, h)
        self.placeholder = placeholder
        self.placeholder_active = True
        self.text = ""
        self.main = scr_parent
        self.color = 'white'
        self.font = pg.font.SysFont("Roboto", font_size)
        self.active = True
    def handle_event(self,event):
        if event.type == pg.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.placeholder_active =False
            else:
                self.placeholder_active = True
        if event.type == pg.KEYDOWN and not self.placeholder_active:
            if event.key == pg.K_BACKSPACE:
                if len(self.text) > 0:
                    self.text = self.text[:-1]
            if event.key == pg.K_RETURN:
                return self.text
            elif event.unicode.isprintable():
                self.text += event.unicode 
    def draw(self):
        if self.active:
            pg.draw.rect(self.main, self.color, self.rect)
            txt_surf = self.font.render(self.text if self.placeholder_active == False else self.placeholder, True, 'black')
            self.main.blit(txt_surf, (self.main.get_width() / 4, self.rect.y))