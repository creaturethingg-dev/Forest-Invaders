import pygame as pg
import sys
import classes

pg.init()
pg.mixer.init()
pg.font.init()
WND_WIDTH = 500
WND_HEIGHT = 650
EXT_MENU_H = 20
screen=pg.display.set_mode((WND_WIDTH, WND_HEIGHT + EXT_MENU_H))
pg.display.set_caption("FOREST INVADERS | FORESTHACKS 2024")
pg.display.set_icon(pg.transform.scale(pg.image.load("data\\sprites\\extinguisher1.png"), (90,90)))
clock=pg.time.Clock()
game_running = True
aliens =[]
ftrs = classes.Feature(WND_WIDTH,WND_HEIGHT + EXT_MENU_H,screen, aliens)
roboto = pg.font.SysFont("Roboto", 32)

#Levels
levels = []
ftrs.implement_level(levels, ftrs.json_data("default_levels.json"))
bullets = []
cur_level = 0
start = False
tb  = classes.TextBox(WND_WIDTH/2 - WND_WIDTH/2.6, (WND_HEIGHT + EXT_MENU_H) / 2,  WND_WIDTH/1.3, 50, "ENTER LVL FILE NAME", screen, 32)
tb.color = 'gray'
music_menu = pg.mixer.Sound("data\\sounds\\main_menu.mp3")
music_menu.set_volume(.3)
music_menu.play(-1)
while not start:
    roboto = pg.font.SysFont("Roboto", 32)
    quitbtn = pg.rect.Rect(WND_WIDTH/2 - WND_WIDTH/2.6, WND_HEIGHT /4 * 2.6, WND_WIDTH/1.3, 50)
    default = pg.rect.Rect(WND_WIDTH/2 - WND_WIDTH/2.6, WND_HEIGHT /4 * 1.5, WND_WIDTH/1.3, 50)
    for event in pg.event.get():
        result =tb.handle_event(event)
        if result:
            ftrs.implement_level(levels, ftrs.json_data(result))
            start = True
        if event.type == pg.QUIT:
            pg.quit()
            sys.exit()
        if event.type == pg.MOUSEBUTTONDOWN:
            if quitbtn.collidepoint(event.pos):
                pg.quit()
                sys.exit()
            if default.collidepoint(event.pos):
                ftrs.implement_level(levels, ftrs.json_data("default_levels.json"))
                start = True
    screen.fill("darkgreen")
    for i in range(1, 5):
        screen.blit(pg.transform.scale(pg.image.load(f"data\\sprites\\alien{i}.png"), (300,300)), ( WND_WIDTH /2 - 150, (EXT_MENU_H * i * 8) - 260 ))
    text_surf = roboto.render("PLAY DEFAULT", True, (0,0,0))
    pg.draw.rect(screen, 'gray', default)
    pg.draw.rect(screen, 'gray', quitbtn)
    screen.blit(text_surf, (WND_WIDTH /3 , default.top))
    text_surf = roboto.render("QUIT", True, (0,0,0))
    screen.blit(text_surf, (WND_WIDTH /2.3 , quitbtn.top))
    tb.draw()
    roboto = pg.font.SysFont("Roboto", 70)
    text_surf = roboto.render("FOREST INVADERS", True, (0,255,0))
    screen.blit(text_surf, (WND_WIDTH/ 2 - 230, EXT_MENU_H))
    pg.display.flip()
    clock.tick(60)
music_menu.stop()
ship = ftrs.load_level(ftrs.find_level(levels, 0))
tb.active = False
roboto = pg.font.SysFont("Roboto", 32)
music_game = pg.mixer.Sound("data\\sounds\\game.mp3")
music_game.set_volume(.34)
music_game.play(-1)
while game_running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            sys.exit()
    screen.fill((0,0,0))
    screen.fill("darkgreen")
    defeated_aliens = 0
    for alien in aliens:
        if alien.rect.bottom >= ship.rect.top + 108:
            game_running = False
        if alien.is_alive:
            alien.draw()
            alien.ai()
        if alien.is_alive == False:
            defeated_aliens +=1
    if defeated_aliens == len(aliens):
        cur_level +=1
        ship=ftrs.load_level(levels[cur_level])
    ship.input_calc(bullets)
    for bullet in bullets:
        bullet.update()
    ship.draw()
    temp_rect = pg.rect.Rect(0,0, WND_WIDTH, EXT_MENU_H)
    pg.draw.rect(screen, 'gray', temp_rect)
    screen.blit(roboto.render(f"LEVEL: {cur_level + 1}", False, 'black'), (0,0))
    pg.display.flip()
    clock.tick(60)
music_game.stop()
aliens =[]
ship = 0
music_over = pg.mixer.Sound("data\\sounds\\game_over.mp3")
music_over.play()
while 1:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            sys.exit()
    screen.fill('black')
    roboto = pg.font.SysFont("Roboto", 90)
    text_surf = roboto.render("GAME OVER", False, 'red')
    screen.blit(text_surf, (WND_WIDTH/2 - 90 * 9 /4, (WND_HEIGHT + EXT_MENU_H)/2))
    pg.draw.aaline(screen, 'red', (0, (WND_HEIGHT + EXT_MENU_H)/2 + 90 * 9 /8), (WND_WIDTH, (WND_HEIGHT + EXT_MENU_H)/2 + 90 * 9 /8))
    pg.draw.aaline(screen, 'red', (0, (WND_HEIGHT + EXT_MENU_H)/2 - 90 * 9 /16), (WND_WIDTH, (WND_HEIGHT + EXT_MENU_H)/2 - 90 * 9 /16))
    pg.display.flip()
    clock.tick

